"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Leaf, Award, Users, ArrowRight, Star, Shield, Truck, Sparkles } from "lucide-react"

export default function HomePage() {
  const [isSignupOpen, setIsSignupOpen] = useState(false)

  const promotions = [
    {
      title: "Premium Indoor Collection",
      description: "Hand-selected strains from master growers",
      discount: "25% OFF",
      validUntil: "Dec 31, 2024",
    },
    {
      title: "Artisan Glass Collection",
      description: "Handcrafted pieces by renowned artists",
      discount: "20% OFF",
      validUntil: "Jan 15, 2025",
    },
    {
      title: "New Member Welcome",
      description: "Exclusive pricing for first-time members",
      discount: "30% OFF",
      validUntil: "Ongoing",
    },
  ]

  const growers = [
    {
      name: "Marcus Chen",
      specialty: "Hydroponic Systems",
      experience: "12 years",
      awards: ["Cannabis Cup Winner 2023", "Best Indoor Grow 2022"],
    },
    {
      name: "Sarah Rodriguez",
      specialty: "Organic Cultivation",
      experience: "8 years",
      awards: ["Sustainable Grower Award", "Organic Excellence 2023"],
    },
    {
      name: "David Thompson",
      specialty: "Genetics & Breeding",
      experience: "15 years",
      awards: ["Strain Innovation Award", "Master Breeder 2023"],
    },
  ]

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="border-b border-sage-800 bg-black/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Leaf className="h-8 w-8 text-forest-500" />
              <span className="text-2xl font-display font-bold text-white">GreenCraft Collective</span>
            </div>
            <nav className="hidden md:flex items-center gap-8">
              <Link href="#about" className="text-sage-300 hover:text-white font-medium transition-colors">
                About
              </Link>
              <Link href="#growers" className="text-sage-300 hover:text-white font-medium transition-colors">
                Growers
              </Link>
              <Link href="#promotions" className="text-sage-300 hover:text-white font-medium transition-colors">
                Promotions
              </Link>
              <Button variant="outline" className="border-sage-600 text-sage-300 hover:bg-sage-800">
                Sign In
              </Button>
              <Button className="premium-gradient text-white font-semibold" onClick={() => setIsSignupOpen(true)}>
                Join Members
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 bg-gradient-to-b from-sage-950 to-black">
        <div className="container mx-auto text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6 leading-tight">
              Premium Cannabis
              <span className="block text-forest-400">Crafted with Excellence</span>
            </h1>
            <p className="text-xl text-sage-300 mb-8 leading-relaxed">
              Experience the finest cannabis products from our award-winning collective of master growers. Where quality
              meets craftsmanship in every harvest.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="premium-gradient text-white px-8 py-4 text-lg font-semibold hover-lift"
                onClick={() => setIsSignupOpen(true)}
              >
                Explore Collection
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-sage-600 text-sage-300 hover:bg-sage-800 px-8 py-4 text-lg"
              >
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 bg-sage-950">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center p-8 rounded-xl dark-glass hover-lift">
              <Shield className="h-12 w-12 text-forest-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Premium Quality</h3>
              <p className="text-sage-300">Lab-tested, pesticide-free products with guaranteed potency</p>
            </div>
            <div className="text-center p-8 rounded-xl dark-glass hover-lift">
              <Award className="h-12 w-12 text-gold-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Award-Winning</h3>
              <p className="text-sage-300">Multiple Cannabis Cup winners and industry recognition</p>
            </div>
            <div className="text-center p-8 rounded-xl dark-glass hover-lift">
              <Truck className="h-12 w-12 text-forest-500 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">Discreet Delivery</h3>
              <p className="text-sage-300">Fast, secure, and confidential delivery service</p>
            </div>
          </div>
        </div>
      </section>

      {/* Promotions */}
      <section id="promotions" className="py-20 px-4 bg-black">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Current Promotions</h2>
            <p className="text-xl text-sage-300">Exclusive offers for our valued members</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {promotions.map((promo, index) => (
              <Card key={index} className="bg-sage-950 border-sage-800 hover-lift">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <CardTitle className="text-white font-display">{promo.title}</CardTitle>
                    <Badge className="gold-gradient text-white font-semibold">{promo.discount}</Badge>
                  </div>
                  <CardDescription className="text-sage-300">{promo.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-sage-400 mb-4">Valid until: {promo.validUntil}</p>
                  <Button className="w-full premium-gradient text-white font-semibold">Claim Offer</Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Our Growers */}
      <section id="growers" className="py-20 bg-sage-950 px-4">
        <div className="container mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-display font-bold text-white mb-4">Master Growers</h2>
            <p className="text-xl text-sage-300">Expert cultivators dedicated to cannabis excellence</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {growers.map((grower, index) => (
              <Card key={index} className="bg-black border-sage-800 hover-lift">
                <CardHeader className="text-center">
                  <div className="w-20 h-20 premium-gradient rounded-full mx-auto mb-4 flex items-center justify-center">
                    <Users className="h-10 w-10 text-white" />
                  </div>
                  <CardTitle className="text-white font-display">{grower.name}</CardTitle>
                  <CardDescription className="text-forest-400 font-semibold">{grower.specialty}</CardDescription>
                </CardHeader>
                <CardContent className="text-center">
                  <p className="text-sage-300 mb-4">{grower.experience} of experience</p>
                  <div className="space-y-2">
                    {grower.awards.map((award, awardIndex) => (
                      <Badge key={awardIndex} variant="outline" className="border-gold-600 text-gold-400 text-xs">
                        <Star className="h-3 w-3 mr-1" />
                        {award}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4 bg-black">
        <div className="container mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl font-display font-bold text-white mb-6">Our Story</h2>
              <p className="text-lg text-sage-300 mb-6 leading-relaxed">
                Founded by a collective of passionate cannabis cultivators, GreenCraft Collective represents the
                pinnacle of cannabis craftsmanship. Our team combines decades of growing experience with cutting-edge
                cultivation techniques.
              </p>
              <p className="text-lg text-sage-300 mb-6 leading-relaxed">
                We believe in sustainable practices, community education, and pushing the boundaries of what's possible
                in cannabis cultivation. Every product reflects our commitment to excellence.
              </p>
              <Button className="premium-gradient text-white font-semibold px-6 py-3">Learn More</Button>
            </div>
            <div className="dark-glass rounded-xl p-8">
              <div className="grid grid-cols-2 gap-6 text-center">
                <div>
                  <div className="text-3xl font-bold text-forest-400 mb-2">15+</div>
                  <div className="text-sage-300">Years Experience</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-gold-400 mb-2">50+</div>
                  <div className="text-sage-300">Awards Won</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-forest-400 mb-2">1000+</div>
                  <div className="text-sage-300">Happy Members</div>
                </div>
                <div>
                  <div className="text-3xl font-bold text-gold-400 mb-2">100%</div>
                  <div className="text-sage-300">Organic</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-sage-950 text-white py-12 border-t border-sage-800">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <Leaf className="h-6 w-6 text-forest-500" />
                <span className="text-xl font-display font-bold">GreenCraft Collective</span>
              </div>
              <p className="text-sage-300">Premium cannabis products crafted with passion and expertise.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-forest-400">Quick Links</h4>
              <div className="space-y-2">
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  About Us
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Products
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Education
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Community
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-forest-400">Support</h4>
              <div className="space-y-2">
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Contact Us
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  FAQ
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Shipping
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Returns
                </Link>
              </div>
            </div>
            <div>
              <h4 className="font-semibold mb-4 text-forest-400">Legal</h4>
              <div className="space-y-2">
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Privacy Policy
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Terms of Service
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Age Verification
                </Link>
                <Link href="#" className="block text-sage-300 hover:text-white transition-colors">
                  Compliance
                </Link>
              </div>
            </div>
          </div>
          <div className="border-t border-sage-800 mt-8 pt-8 text-center">
            <p className="text-sage-300">&copy; 2024 GreenCraft Collective. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* Signup Modal */}
      {isSignupOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-sage-950 border-sage-800">
            <CardHeader>
              <CardTitle className="text-white font-display">Join Members Area</CardTitle>
              <CardDescription className="text-sage-300">Access premium cannabis products</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Link href="/signup">
                  <Button className="w-full premium-gradient text-white font-semibold">
                    <Sparkles className="mr-2 h-4 w-4" />
                    Get Started
                  </Button>
                </Link>
                <Button className="w-full" variant="outline" onClick={() => setIsSignupOpen(false)}>
                  Close
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}
