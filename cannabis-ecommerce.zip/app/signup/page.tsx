"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Checkbox } from "@/components/ui/checkbox"
import { Leaf, Shield, MapPin, User, Calendar, Phone, Mail } from "lucide-react"
import Link from "next/link"

export default function SignupPage() {
  const [formData, setFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    dateOfBirth: "",
    address: "",
    city: "",
    state: "",
    zipCode: "",
    agreeTerms: false,
    ageVerified: false,
  })

  const [errors, setErrors] = useState({})

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
    if (errors[field]) {
      setErrors((prev) => ({ ...prev, [field]: null }))
    }
  }

  const validateAge = (dateOfBirth) => {
    const today = new Date()
    const birthDate = new Date(dateOfBirth)
    const age = today.getFullYear() - birthDate.getFullYear()
    const monthDiff = today.getMonth() - birthDate.getMonth()

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      return age - 1
    }
    return age
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const newErrors = {}

    // Validation
    if (!formData.fullName) newErrors.fullName = "Full name is required"
    if (!formData.email) newErrors.email = "Email is required"
    if (!formData.phone) newErrors.phone = "Phone number is required"
    if (!formData.dateOfBirth) newErrors.dateOfBirth = "Date of birth is required"
    if (!formData.address) newErrors.address = "Address is required"
    if (!formData.city) newErrors.city = "City is required"
    if (!formData.state) newErrors.state = "State is required"
    if (!formData.zipCode) newErrors.zipCode = "Zip code is required"
    if (!formData.agreeTerms) newErrors.agreeTerms = "You must agree to the terms"
    if (!formData.ageVerified) newErrors.ageVerified = "Age verification is required"

    // Age validation
    if (formData.dateOfBirth) {
      const age = validateAge(formData.dateOfBirth)
      if (age < 21) {
        newErrors.dateOfBirth = "You must be 21 or older to access our services"
      }
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors)
      return
    }

    // Success - redirect to members area
    alert("Account created successfully! Redirecting to members area...")
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="border-b border-sage-800 bg-black/95 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <Leaf className="h-8 w-8 text-forest-500" />
              <span className="text-2xl font-display font-bold text-white">GreenCraft Collective</span>
            </Link>
            <Link href="/">
              <Button variant="outline" className="border-sage-600 text-sage-300 hover:bg-sage-800">
                Back to Home
              </Button>
            </Link>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          <Card className="bg-sage-950 border-sage-800">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-display text-white">Join Our Members Area</CardTitle>
              <CardDescription className="text-lg text-sage-300">
                Access premium cannabis products and exclusive content
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Age Verification Notice */}
              <div className="dark-glass rounded-lg p-6 mb-8 border border-gold-600/30">
                <div className="flex items-center gap-3 mb-3">
                  <Shield className="h-6 w-6 text-gold-500" />
                  <span className="font-semibold text-gold-400 text-lg">Age Verification Required</span>
                </div>
                <p className="text-sage-300">
                  You must be 21 years or older to access our cannabis products. We verify all member information for
                  compliance with local laws and regulations.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-8">
                {/* Personal Information */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3 mb-4">
                    <User className="h-6 w-6 text-forest-500" />
                    <h3 className="text-xl font-semibold text-white">Personal Information</h3>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="fullName" className="text-sage-300 font-medium">
                        Full Name *
                      </Label>
                      <Input
                        id="fullName"
                        value={formData.fullName}
                        onChange={(e) => handleInputChange("fullName", e.target.value)}
                        className={`mt-2 bg-black border-sage-700 text-white h-12 ${
                          errors.fullName ? "border-red-500" : ""
                        }`}
                        placeholder="Enter your full name"
                      />
                      {errors.fullName && <p className="text-red-400 text-sm mt-2">{errors.fullName}</p>}
                    </div>

                    <div>
                      <Label htmlFor="email" className="text-sage-300 font-medium">
                        Email Address *
                      </Label>
                      <div className="relative mt-2">
                        <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-400 h-5 w-5" />
                        <Input
                          id="email"
                          type="email"
                          value={formData.email}
                          onChange={(e) => handleInputChange("email", e.target.value)}
                          className={`pl-12 bg-black border-sage-700 text-white h-12 ${
                            errors.email ? "border-red-500" : ""
                          }`}
                          placeholder="your@email.com"
                        />
                      </div>
                      {errors.email && <p className="text-red-400 text-sm mt-2">{errors.email}</p>}
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <Label htmlFor="phone" className="text-sage-300 font-medium">
                        Phone Number *
                      </Label>
                      <div className="relative mt-2">
                        <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-400 h-5 w-5" />
                        <Input
                          id="phone"
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => handleInputChange("phone", e.target.value)}
                          className={`pl-12 bg-black border-sage-700 text-white h-12 ${
                            errors.phone ? "border-red-500" : ""
                          }`}
                          placeholder="(555) 123-4567"
                        />
                      </div>
                      {errors.phone && <p className="text-red-400 text-sm mt-2">{errors.phone}</p>}
                    </div>

                    <div>
                      <Label htmlFor="dateOfBirth" className="text-sage-300 font-medium">
                        Date of Birth *
                      </Label>
                      <div className="relative mt-2">
                        <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-sage-400 h-5 w-5" />
                        <Input
                          id="dateOfBirth"
                          type="date"
                          value={formData.dateOfBirth}
                          onChange={(e) => handleInputChange("dateOfBirth", e.target.value)}
                          className={`pl-12 bg-black border-sage-700 text-white h-12 ${
                            errors.dateOfBirth ? "border-red-500" : ""
                          }`}
                        />
                      </div>
                      {errors.dateOfBirth && <p className="text-red-400 text-sm mt-2">{errors.dateOfBirth}</p>}
                    </div>
                  </div>
                </div>

                {/* Address Information */}
                <div className="space-y-6">
                  <div className="flex items-center gap-3 mb-4">
                    <MapPin className="h-6 w-6 text-forest-500" />
                    <h3 className="text-xl font-semibold text-white">Address Information</h3>
                  </div>

                  <div>
                    <Label htmlFor="address" className="text-sage-300 font-medium">
                      Street Address *
                    </Label>
                    <Input
                      id="address"
                      value={formData.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                      className={`mt-2 bg-black border-sage-700 text-white h-12 ${
                        errors.address ? "border-red-500" : ""
                      }`}
                      placeholder="123 Main Street"
                    />
                    {errors.address && <p className="text-red-400 text-sm mt-2">{errors.address}</p>}
                  </div>

                  <div className="grid md:grid-cols-3 gap-6">
                    <div>
                      <Label htmlFor="city" className="text-sage-300 font-medium">
                        City *
                      </Label>
                      <Input
                        id="city"
                        value={formData.city}
                        onChange={(e) => handleInputChange("city", e.target.value)}
                        className={`mt-2 bg-black border-sage-700 text-white h-12 ${
                          errors.city ? "border-red-500" : ""
                        }`}
                        placeholder="City"
                      />
                      {errors.city && <p className="text-red-400 text-sm mt-2">{errors.city}</p>}
                    </div>

                    <div>
                      <Label htmlFor="state" className="text-sage-300 font-medium">
                        State *
                      </Label>
                      <Input
                        id="state"
                        value={formData.state}
                        onChange={(e) => handleInputChange("state", e.target.value)}
                        className={`mt-2 bg-black border-sage-700 text-white h-12 ${
                          errors.state ? "border-red-500" : ""
                        }`}
                        placeholder="State"
                      />
                      {errors.state && <p className="text-red-400 text-sm mt-2">{errors.state}</p>}
                    </div>

                    <div>
                      <Label htmlFor="zipCode" className="text-sage-300 font-medium">
                        Zip Code *
                      </Label>
                      <Input
                        id="zipCode"
                        value={formData.zipCode}
                        onChange={(e) => handleInputChange("zipCode", e.target.value)}
                        className={`mt-2 bg-black border-sage-700 text-white h-12 ${
                          errors.zipCode ? "border-red-500" : ""
                        }`}
                        placeholder="12345"
                      />
                      {errors.zipCode && <p className="text-red-400 text-sm mt-2">{errors.zipCode}</p>}
                    </div>
                  </div>
                </div>

                {/* Terms and Verification */}
                <div className="space-y-6">
                  <div className="dark-glass rounded-lg p-6 space-y-4">
                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="ageVerified"
                        checked={formData.ageVerified}
                        onCheckedChange={(checked) => handleInputChange("ageVerified", checked)}
                        className="mt-1"
                      />
                      <Label htmlFor="ageVerified" className="text-sage-300 leading-relaxed">
                        I certify that I am 21 years of age or older and legally allowed to purchase cannabis products
                        in my jurisdiction. *
                      </Label>
                    </div>
                    {errors.ageVerified && <p className="text-red-400 text-sm">{errors.ageVerified}</p>}

                    <div className="flex items-start space-x-3">
                      <Checkbox
                        id="agreeTerms"
                        checked={formData.agreeTerms}
                        onCheckedChange={(checked) => handleInputChange("agreeTerms", checked)}
                        className="mt-1"
                      />
                      <Label htmlFor="agreeTerms" className="text-sage-300 leading-relaxed">
                        I agree to the{" "}
                        <Link href="#" className="text-forest-400 hover:text-forest-300 underline">
                          Terms of Service
                        </Link>{" "}
                        and{" "}
                        <Link href="#" className="text-forest-400 hover:text-forest-300 underline">
                          Privacy Policy
                        </Link>{" "}
                        *
                      </Label>
                    </div>
                    {errors.agreeTerms && <p className="text-red-400 text-sm">{errors.agreeTerms}</p>}
                  </div>
                </div>

                <Button type="submit" className="w-full premium-gradient text-white py-4 text-lg font-semibold">
                  Create Account & Enter Members Area
                </Button>
              </form>

              <div className="mt-8 text-center">
                <p className="text-sage-300">
                  Already have an account?{" "}
                  <Link href="/signin" className="text-forest-400 hover:text-forest-300 font-semibold underline">
                    Sign in here
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
