"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Progress } from "@/components/ui/progress"
import { Leaf, Search, ShoppingCart, Star, User, Grid, List, Filter, Clock, Award, MapPin } from "lucide-react"

export default function MembersShop() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedSubCategory, setSelectedSubCategory] = useState("all")
  const [viewMode, setViewMode] = useState("grid")
  const [cartItems, setCartItems] = useState([])
  const [selectedProduct, setSelectedProduct] = useState(null)

  const categories = {
    all: { name: "All Products", subcategories: [] },
    flowers: {
      name: "Flowers",
      subcategories: [
        { id: "sativa", name: "Sativa" },
        { id: "indica", name: "Indica" },
        { id: "hybrid", name: "Hybrid" },
      ],
    },
    glassware: {
      name: "Glassware",
      subcategories: [
        { id: "bongs", name: "Bongs" },
        { id: "pipes", name: "Pipes" },
        { id: "accessories", name: "Accessories" },
      ],
    },
    artwork: {
      name: "Artwork",
      subcategories: [
        { id: "prints", name: "Prints" },
        { id: "sculptures", name: "Sculptures" },
        { id: "photography", name: "Photography" },
      ],
    },
  }

  const products = [
    {
      id: 1,
      name: "Purple Haze Premium",
      category: "flowers",
      subcategory: "sativa",
      price: 45.0,
      thc: 22,
      cbd: 1,
      strain: "Sativa Dominant",
      indicaPercent: 20,
      sativaPercent: 80,
      rating: 4.8,
      reviews: 124,
      inStock: 8,
      lowStock: true,
      grower: {
        name: "Marcus Chen",
        experience: "12 years",
        specialty: "Hydroponic Systems",
        location: "Northern California",
      },
      images: [
        "/placeholder.svg?height=400&width=400",
        "/placeholder.svg?height=400&width=400",
        "/placeholder.svg?height=400&width=400",
      ],
      description:
        "Classic sativa with uplifting effects and sweet berry aroma. Perfect for creative endeavors and social activities.",
      effects: ["Creative", "Uplifting", "Energetic", "Happy"],
      terpenes: ["Limonene", "Myrcene", "Pinene"],
      flavors: ["Berry", "Sweet", "Citrus"],
      harvestDate: "2024-01-15",
    },
    {
      id: 2,
      name: "OG Kush Indoor",
      category: "flowers",
      subcategory: "indica",
      price: 50.0,
      thc: 24,
      cbd: 0.5,
      strain: "Indica Dominant",
      indicaPercent: 75,
      sativaPercent: 25,
      rating: 4.9,
      reviews: 89,
      inStock: 15,
      lowStock: false,
      grower: {
        name: "Sarah Rodriguez",
        experience: "8 years",
        specialty: "Organic Cultivation",
        location: "Oregon",
      },
      images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
      description:
        "Premium indoor grown OG Kush with earthy pine flavors. Known for its relaxing and sedating effects.",
      effects: ["Relaxed", "Sleepy", "Happy", "Euphoric"],
      terpenes: ["Linalool", "Caryophyllene", "Humulene"],
      flavors: ["Pine", "Earthy", "Woody"],
      harvestDate: "2024-01-20",
    },
    {
      id: 3,
      name: "Artisan Glass Pipe",
      category: "glassware",
      subcategory: "pipes",
      price: 85.0,
      artist: "Sarah Chen",
      rating: 4.7,
      reviews: 45,
      inStock: 3,
      lowStock: true,
      images: ["/placeholder.svg?height=400&width=400", "/placeholder.svg?height=400&width=400"],
      description: "Hand-blown borosilicate glass pipe with unique color patterns and smooth airflow.",
      materials: ["Borosilicate Glass", "Silver Fuming"],
      dimensions: "4.5 inches long",
    },
    {
      id: 4,
      name: "Cannabis Leaf Print",
      category: "artwork",
      subcategory: "prints",
      price: 35.0,
      artist: "Marcus Rodriguez",
      size: "16x20 inches",
      rating: 4.6,
      reviews: 32,
      inStock: 12,
      lowStock: false,
      images: ["/placeholder.svg?height=400&width=400"],
      description: "Limited edition botanical art print on premium paper with archival inks.",
      materials: ["Archival Paper", "Pigment Inks"],
      edition: "Limited to 100 prints",
    },
    {
      id: 5,
      name: "Hybrid Balance",
      category: "flowers",
      subcategory: "hybrid",
      price: 42.0,
      thc: 20,
      cbd: 3,
      strain: "Hybrid",
      indicaPercent: 50,
      sativaPercent: 50,
      rating: 4.5,
      reviews: 67,
      inStock: 0,
      lowStock: false,
      grower: {
        name: "David Thompson",
        experience: "15 years",
        specialty: "Genetics & Breeding",
        location: "Colorado",
      },
      images: ["/placeholder.svg?height=400&width=400"],
      description:
        "Perfectly balanced hybrid ideal for any time of day. Offers both mental clarity and physical relaxation.",
      effects: ["Balanced", "Focused", "Relaxed", "Creative"],
      terpenes: ["Terpinolene", "Ocimene", "Carene"],
      flavors: ["Floral", "Herbal", "Sweet"],
      harvestDate: "2024-01-10",
    },
  ]

  const filteredProducts = products.filter((product) => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesCategory = selectedCategory === "all" || product.category === selectedCategory
    const matchesSubCategory = selectedSubCategory === "all" || product.subcategory === selectedSubCategory
    return matchesSearch && matchesCategory && matchesSubCategory
  })

  const handleCategoryChange = (category) => {
    setSelectedCategory(category)
    setSelectedSubCategory("all")
  }

  const addToCart = (product) => {
    setCartItems((prev) => [...prev, product])
  }

  const ProductDetailDialog = ({ product, onClose }) => {
    if (!product) return null

    return (
      <Dialog open={!!product} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-sage-950 border-sage-800 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl font-display text-white">{product.name}</DialogTitle>
          </DialogHeader>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Images */}
            <div className="space-y-4">
              <div className="relative">
                <Image
                  src={product.images?.[0] || "/placeholder.svg"}
                  alt={product.name}
                  width={400}
                  height={400}
                  className="w-full h-80 object-cover rounded-lg"
                />
                {product.lowStock && (
                  <Badge className="absolute top-3 right-3 bg-gold-600 text-white animate-pulse">
                    <Clock className="h-3 w-3 mr-1" />
                    Low Stock!
                  </Badge>
                )}
              </div>
              {product.images?.length > 1 && (
                <div className="grid grid-cols-3 gap-2">
                  {product.images.slice(1).map((image, index) => (
                    <Image
                      key={index}
                      src={image || "/placeholder.svg"}
                      alt={`${product.name} ${index + 2}`}
                      width={120}
                      height={120}
                      className="w-full h-24 object-cover rounded"
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Product Info */}
            <div className="space-y-6">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <Badge className="premium-gradient text-white mb-2 capitalize">{product.category}</Badge>
                    <div className="flex items-center gap-2">
                      <Star className="h-5 w-5 fill-gold-400 text-gold-400" />
                      <span className="text-lg font-semibold">{product.rating}</span>
                      <span className="text-sage-400">({product.reviews} reviews)</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-white">${product.price}</div>
                    <div className="text-sage-400">
                      {product.inStock > 0 ? `${product.inStock} in stock` : "Out of stock"}
                    </div>
                  </div>
                </div>

                <p className="text-sage-300 text-lg leading-relaxed">{product.description}</p>
              </div>

              {/* Cannabis-specific info */}
              {product.category === "flowers" && (
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="dark-glass rounded-lg p-4">
                      <div className="text-sm text-sage-400 mb-1">THC Content</div>
                      <div className="flex items-center gap-2">
                        <Progress value={product.thc} max={30} className="flex-1" />
                        <span className="text-forest-400 font-bold">{product.thc}%</span>
                      </div>
                    </div>
                    <div className="dark-glass rounded-lg p-4">
                      <div className="text-sm text-sage-400 mb-1">CBD Content</div>
                      <div className="flex items-center gap-2">
                        <Progress value={product.cbd} max={20} className="flex-1" />
                        <span className="text-forest-400 font-bold">{product.cbd}%</span>
                      </div>
                    </div>
                  </div>

                  <div className="dark-glass rounded-lg p-4">
                    <div className="text-sm text-sage-400 mb-2">Strain Composition</div>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sage-300">Indica</span>
                        <span className="text-purple-400 font-bold">{product.indicaPercent}%</span>
                      </div>
                      <Progress value={product.indicaPercent} className="h-2" />
                      <div className="flex justify-between items-center">
                        <span className="text-sage-300">Sativa</span>
                        <span className="text-forest-400 font-bold">{product.sativaPercent}%</span>
                      </div>
                      <Progress value={product.sativaPercent} className="h-2" />
                    </div>
                  </div>

                  {product.effects && (
                    <div>
                      <div className="text-sm text-sage-400 mb-2">Effects</div>
                      <div className="flex flex-wrap gap-2">
                        {product.effects.map((effect, index) => (
                          <Badge key={index} variant="outline" className="border-forest-500 text-forest-400">
                            {effect}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {product.terpenes && (
                    <div>
                      <div className="text-sm text-sage-400 mb-2">Terpenes</div>
                      <div className="flex flex-wrap gap-2">
                        {product.terpenes.map((terpene, index) => (
                          <Badge key={index} variant="outline" className="border-purple-500 text-purple-400">
                            {terpene}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {product.flavors && (
                    <div>
                      <div className="text-sm text-sage-400 mb-2">Flavors</div>
                      <div className="flex flex-wrap gap-2">
                        {product.flavors.map((flavor, index) => (
                          <Badge key={index} variant="outline" className="border-gold-500 text-gold-400">
                            {flavor}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Grower Info */}
                  {product.grower && (
                    <div className="dark-glass rounded-lg p-4">
                      <div className="flex items-center gap-3 mb-3">
                        <Award className="h-5 w-5 text-gold-500" />
                        <span className="font-semibold text-white">Master Grower</span>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between">
                          <span className="text-sage-400">Name:</span>
                          <span className="text-white font-semibold">{product.grower.name}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sage-400">Experience:</span>
                          <span className="text-forest-400">{product.grower.experience}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-sage-400">Specialty:</span>
                          <span className="text-sage-300">{product.grower.specialty}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sage-400">Location:</span>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4 text-sage-400" />
                            <span className="text-sage-300">{product.grower.location}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Glassware/Artwork info */}
              {(product.category === "glassware" || product.category === "artwork") && (
                <div className="space-y-4">
                  <div className="dark-glass rounded-lg p-4">
                    <div className="flex items-center gap-3 mb-3">
                      <Award className="h-5 w-5 text-gold-500" />
                      <span className="font-semibold text-white">Artist</span>
                    </div>
                    <div className="text-lg text-gold-400 font-semibold">{product.artist}</div>
                  </div>

                  {product.materials && (
                    <div>
                      <div className="text-sm text-sage-400 mb-2">Materials</div>
                      <div className="flex flex-wrap gap-2">
                        {product.materials.map((material, index) => (
                          <Badge key={index} variant="outline" className="border-sage-500 text-sage-400">
                            {material}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {product.dimensions && (
                    <div className="flex justify-between">
                      <span className="text-sage-400">Dimensions:</span>
                      <span className="text-white">{product.dimensions}</span>
                    </div>
                  )}

                  {product.edition && (
                    <div className="flex justify-between">
                      <span className="text-sage-400">Edition:</span>
                      <span className="text-gold-400">{product.edition}</span>
                    </div>
                  )}
                </div>
              )}

              <Button
                className={`w-full ${product.inStock > 0 ? "premium-gradient" : "bg-gray-600"} text-white py-3 text-lg`}
                disabled={product.inStock === 0}
                onClick={() => {
                  addToCart(product)
                  onClose()
                }}
              >
                {product.inStock > 0 ? "Add to Cart" : "Out of Stock"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Header */}
      <header className="border-b border-sage-800 bg-black/95 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-3">
              <Leaf className="h-8 w-8 text-forest-500" />
              <span className="text-2xl font-display font-bold text-white">GreenCraft</span>
            </Link>
            <nav className="hidden md:flex items-center gap-8">
              <Link href="/members" className="text-white font-medium border-b-2 border-forest-500 pb-1">
                Shop
              </Link>
              <Link href="/members/community" className="text-sage-300 hover:text-white font-medium transition-colors">
                Community
              </Link>
              <Link href="/members/growers" className="text-sage-300 hover:text-white font-medium transition-colors">
                Growers
              </Link>
              <Button variant="outline" className="relative border-sage-600 text-sage-300">
                <ShoppingCart className="h-4 w-4" />
                {cartItems.length > 0 && (
                  <Badge className="absolute -top-2 -right-2 gold-gradient text-white text-xs">
                    {cartItems.length}
                  </Badge>
                )}
              </Button>
              <Button variant="outline" className="border-sage-600 text-sage-300">
                <User className="h-4 w-4 mr-2" />
                Profile
              </Button>
            </nav>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Header Section */}
        <div className="mb-8">
          <h1 className="text-4xl font-display font-bold text-white mb-2">Premium Cannabis Shop</h1>
          <p className="text-xl text-sage-300">Discover our curated collection of premium products</p>
        </div>

        {/* Search Bar */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-sage-400 h-5 w-5" />
            <Input
              placeholder="Search products..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 bg-sage-950 border-sage-700 text-white placeholder-sage-400 h-12"
            />
          </div>
        </div>

        {/* Category Navigation - Modern Tab Style */}
        <div className="mb-8">
          <Tabs value={selectedCategory} onValueChange={handleCategoryChange} className="w-full">
            <TabsList className="grid w-full grid-cols-4 bg-sage-950 border border-sage-700 h-12">
              {Object.entries(categories).map(([key, category]) => (
                <TabsTrigger
                  key={key}
                  value={key}
                  className="data-[state=active]:bg-forest-600 data-[state=active]:text-white text-sage-300"
                >
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Subcategory Navigation - Improved Integration */}
          {selectedCategory !== "all" && categories[selectedCategory]?.subcategories.length > 0 && (
            <div className="mb-6">
              <div className="bg-sage-950 border border-sage-800 rounded-lg p-4">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-1 h-6 bg-forest-500 rounded-full"></div>
                  <h3 className="text-lg font-semibold text-white">{categories[selectedCategory].name} Categories</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button
                    variant={selectedSubCategory === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedSubCategory("all")}
                    className={
                      selectedSubCategory === "all"
                        ? "gold-gradient text-white"
                        : "border-sage-700 text-sage-400 hover:bg-sage-900 hover:text-sage-300"
                    }
                  >
                    All {categories[selectedCategory].name}
                  </Button>
                  {categories[selectedCategory].subcategories.map((sub) => (
                    <Button
                      key={sub.id}
                      variant={selectedSubCategory === sub.id ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedSubCategory(sub.id)}
                      className={
                        selectedSubCategory === sub.id
                          ? "gold-gradient text-white"
                          : "border-sage-700 text-sage-400 hover:bg-sage-900 hover:text-sage-300"
                      }
                    >
                      {sub.name}
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Filters and View Toggle */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-4">
            <Filter className="h-5 w-5 text-sage-400" />
            <p className="text-sage-300">
              Showing {filteredProducts.length} of {products.length} products
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant={viewMode === "grid" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("grid")}
              className={viewMode === "grid" ? "premium-gradient" : "border-sage-600 text-sage-300"}
            >
              <Grid className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode("list")}
              className={viewMode === "list" ? "premium-gradient" : "border-sage-600 text-sage-300"}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Product Grid */}
        <div className={viewMode === "grid" ? "grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" : "space-y-4"}>
          {filteredProducts.map((product) => (
            <Card
              key={product.id}
              className={`bg-sage-950 border-sage-800 hover-lift overflow-hidden group cursor-pointer ${
                viewMode === "list" ? "flex flex-row" : ""
              }`}
              onClick={() => setSelectedProduct(product)}
            >
              <div className={viewMode === "list" ? "w-48 flex-shrink-0" : ""}>
                <div className="relative">
                  <Image
                    src={product.images?.[0] || "/placeholder.svg"}
                    alt={product.name}
                    width={300}
                    height={300}
                    className={`object-cover transition-transform group-hover:scale-105 ${
                      viewMode === "list" ? "w-full h-48" : "w-full h-56"
                    }`}
                  />
                  {product.lowStock && (
                    <Badge className="absolute top-3 right-3 bg-gold-600 text-white animate-pulse">
                      <Clock className="h-3 w-3 mr-1" />
                      Low Stock!
                    </Badge>
                  )}
                  {!product.inStock && (
                    <Badge className="absolute top-3 right-3 bg-red-600 text-white">Out of Stock</Badge>
                  )}
                  <Badge className="absolute top-3 left-3 premium-gradient text-white capitalize">
                    {product.category}
                  </Badge>
                </div>
              </div>

              <div className={`p-6 ${viewMode === "list" ? "flex-1" : ""}`}>
                <div className="flex justify-between items-start mb-3">
                  <CardTitle className="text-white font-display text-lg">{product.name}</CardTitle>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-gold-400 text-gold-400" />
                    <span className="text-sm text-sage-300">{product.rating}</span>
                  </div>
                </div>

                <CardDescription className="text-sage-300 mb-4">{product.description}</CardDescription>

                {product.category === "flowers" && (
                  <div className="flex gap-2 mb-4 flex-wrap">
                    <Badge variant="outline" className="border-forest-500 text-forest-400 text-xs">
                      THC: {product.thc}%
                    </Badge>
                    <Badge variant="outline" className="border-sage-500 text-sage-400 text-xs">
                      CBD: {product.cbd}%
                    </Badge>
                    <Badge variant="outline" className="border-gold-500 text-gold-400 text-xs">
                      {product.strain}
                    </Badge>
                  </div>
                )}

                {(product.category === "glassware" || product.category === "artwork") && (
                  <p className="text-sm text-gold-400 mb-4">By {product.artist}</p>
                )}

                <div className="flex justify-between items-center">
                  <span className="text-2xl font-bold text-white">${product.price}</span>
                  <Button
                    className={product.inStock > 0 ? "premium-gradient" : "bg-gray-600"}
                    disabled={product.inStock === 0}
                    onClick={(e) => {
                      e.stopPropagation()
                      addToCart(product)
                    }}
                  >
                    {product.inStock > 0 ? "Add to Cart" : "Out of Stock"}
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>

        {filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-sage-300 text-lg mb-4">No products found matching your criteria.</p>
            <Button
              className="premium-gradient"
              onClick={() => {
                setSearchQuery("")
                setSelectedCategory("all")
                setSelectedSubCategory("all")
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>

      {/* Product Detail Dialog */}
      <ProductDetailDialog product={selectedProduct} onClose={() => setSelectedProduct(null)} />
    </div>
  )
}
